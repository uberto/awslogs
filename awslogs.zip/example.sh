#!/usr/bin/env bash
lein run fixtures pinboard
